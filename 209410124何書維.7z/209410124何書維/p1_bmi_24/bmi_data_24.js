export const bmi = [
    {
        id: 1,
        height: 1.75,
        weight: 55
    },
    {
        id: 2,
        height: 1.75,
        weight: 70
    },
    {
        id: 3,
        height: 1.75,
        weight: 85
 
    }
];

//(1.75, 55), (1.75, 70), (1.75, 85)