// let height = Number(prompt('輸入你的身高，以公分計算')) / 100;
// let weight = Number(prompt('輸入你的體種，以公斤計算'));

// function bmiCalc_24(height, weight) {}
// function bmiCalcSuggest_24(height, weight) {}



const bmi_data_24 = [];


bmi=(weight/(height*height));
console.log('bmi',bmi);
bmiCalcSuggest_24(1.75, 55);
bmiCalcSuggest_24(1.75, 70);
bmiCalcSuggest_24(1.75, 85);

