// set inital value to zero
let count = 0;
// select value and buttons
const value = document.querySelector('value');
const btns = document.querySelectorAll('.btn');

btns.forEach(function (btn) {
  btn.addEventListener('click', function (e) {});
});

const Btndecrease=document.querySelector('.btn');
const Btnreset=document.querySelector('.btn');
const Btnincrease=document.querySelector('.btn');

Btndecrease.addEventListener('click',()=>{
value ++ ;

});



if(value >= 0){
  value.style.backgroundColor = 'rgba(144, 238, 144, 0.5)';
} else {
  value.style.backgroundColor = 'rgba(240, 118, 128, 0.726)';
}