let tours_xx = [];

const displayTours_xx = ({ tours }) => {};

const fetchTours_xx = async () => {};

window.addEventListener('DOMContentLoaded', () => {
  fetchTours_xx(url);
});

export const menu = [
  {
      id: 1,
      title: 'Best ireland in 14 days tour',
      price: 12.59,
      img: './ireland.jpeg',
      remote_img: '',
      desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita architecto, cupiditate molestias quisquam error quam blanditiis tempore quo dicta. Ipsa.'
  },
  {
      id: 2,
      title: 'Best italy in 7 days tour ',
      price: 12.59,
      img: './italy.jpeg',
      remote_img: '',
      desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita architecto, cupiditate molestias quisquam error quam blanditiis tempore quo dicta. Ipsa.'
  },
  {
      id: 3,
      title: 'Best paris in 6 days tour ',
      price: 12.59,
      img: './paris.jpg',
      remote_img: '',
      desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita architecto, cupiditate molestias quisquam error quam blanditiis tempore quo dicta. Ipsa.'
  },
  {
      id: 4,
      title: 'Best poland in 5 days tour',
      price: 15.59,
      img: './poland.jpeg',
      remote_img: '',
      desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita architecto, cupiditate molestias quisquam error quam blanditiis tempore quo dicta. Ipsa.'
  },
  {
      id: 5,
      title: 'Best vienna in 8 days tour',
      price: 13.99,
      img: './vienna.jpeg',
      remote_img: '',
      desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita architecto, cupiditate molestias quisquam error quam blanditiis tempore quo dicta. Ipsa.'
  },
];